from __future__ import annotations

from basedpyright.run_node import run


def main():
    run("index")
