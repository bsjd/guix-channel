import version from './version.json';

export const toolName = 'basedpyright';

export const website = `https://docs.basedpyright.com/v${version}`;
