// This is an entry-point for debugging the pyright CLI
require('./out/packages/pyright-internal/src/pyright').main();
